<?php
$tag = 'Latest Posts';
//call header and nav
require 'head.php';
//call the search box which is after the navbar
require 'searchbox.php';
?>
<h3> Latest Posts </h3>
<?php
//if id is not set then refer the url parameter to 1 
//if not then get the id adn pass it to the url
if (!isset($_GET['id'])) {
	$id = 1;
} else {
	$id = $_GET['id'];
}
//the same logic as index.php file except some differences
//which is the usage of substr explained later in this page

$start = 0;
$limit = 10;
$start = ($id - 1) * $limit;
$sql = "SELECT * FROM `posts` ORDER BY ID DESC LIMIT $start, $limit";
$results = $pdo->query($sql)->fetchAll();
$rows = count($results);
$total = ceil($rows / $limit);
if (count($results) < 1) {
	echo 'No Post added yet!';
} else {
	foreach ($pdo->query($sql) as $row) {
		require 'date.php';
		echo '<a style="text-decoration:none;color:black;" href="readmore.php?id=' . $row['ID'] . '">';
		if ($row['Image']) {
			//stated in index.php
			echo '<p align="center"><img src="admin/' . $row['Image'] . '" " height="240px" width="50%"></p>';
		}
		echo '<h3 align="center"> ' . $row['Title'] . '<br></a><span style="font-size:13px;">By: <a href="anchor.php?anc=' . $row['Anchor'] . '" style="text-decoration:none;color:black;font-size:13px;">' . $row['Anchor'] . '</a> | ' . $row['Category'] . '</span></h3>

	<a style="text-decoration:none;color:black;" href="readmore.php?id=' . $row['ID'] . '">
		<p align="justify">' .

			//as said before use of substr. In this page n12br is used which
			//creates a break equivalent to <br> tag in html
			//ref : https://thisinterestsme.com/php-get-first-character-string/
			//substr function returns a part of a string , in this case it will 
			//start from index 0 and will end to index 20
			substr(nl2br($row['Content']), 0, 20) . '... <i style="color: red;">Read More</i> </p>
	</a>

	<p align="right">' . $d . ' ' . $dc . ', ' . $dy . ' </p>
	<hr>';
	}
	//stated in index.php file
	if ($id > 1) {
		echo '<a href="?id=' . $id - 1 . '">Prev </a>';
	}
	if ($id < $total) {
		echo '<a href="?id=' . $id + 1 . '">Next </a>';
	}
}
require 'footer.php'; ?>
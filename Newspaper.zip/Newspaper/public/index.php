<?php
$tag = 'Home';
//call the navbar
require 'head.php';
//call the search box which is after the navbar
require 'searchbox.php';

//undefined index id error found when !isset was not included

//if id is not set then refer the url parameter to 1 
//if not then get the id adn pass it to the url
if (!isset($_GET['id'])) {
	$id = 1;
} else {
	$id = $_GET['id'];
}
//set the variable start to 0 and limit to 10 for querying purposes.
//assuming there will not be more than 10 posts on each page
//idea from
//https://www.phpjabbers.com/php--mysql-select-data-and-split-on-pages-php25.html
$start = 0;
$limit = 10;
$start = ($id - 1) * $limit;

//ref
//https://stackoverflow.com/questions/37872654/pagination-ceiling-an-array-using-pdo

//select query to get all data from posts table
$sql = "SELECT * FROM posts ORDER BY ID DESC LIMIT $start, $limit";
//execute and fetch all the row from the above query
$results  = $pdo->query($sql)->fetchAll();
//counts the all items from the execution
$rows = count($results);
//https://stackoverflow.com/questions/37872654/pagination-ceiling-an-array-using-pdo
$total = ceil($rows / $limit);
//if the count function returns 0 on $results
//which means there are no rows to be returned basically means false
if (count($results) < 1) {
	echo 'No Post added yet!';
} else {
	//go through each and every row from the query executed before
	foreach ($pdo->query($sql) as $row) {
		//calling the file which has the scripts to display date of posts, inspired from lecture
		require 'date.php';
		//link to readmore.php file which will lead to the page containing details about the articles posted
		echo '<a style="text-decoration:none;color:black;" href="readmore.php?id=' . $row['ID'] . '">';
		//if the query goes through each and every row and finds the image index then run this
		//the directory for the image is admin which contains the folder for image.
		//so this statement will go through that folder and will search the value of that image, if it contains the image
		//it will display the image in below format
		if ($row['Image']) {
			echo '<p align="center"><img src="admin/' . $row['Image'] . '" height="240px" width="50%"></p>';
		}
		//print the title of the post from row called Title and the name of the author
		//after the a href="anchor.php.... it will replace the author name in the url parameter , linked to anchor.php file
		echo '<h3 align="center"> ' . $row['Title'] . '<br></a><span style="font-size:13px;"> By: <a href="anchor.php?anc=' . $row['Anchor'] . '" style="text-decoration:none;color:black;font-size:13px">' . $row['Anchor'] . '</a> </span></h3>
		<br>
							
							<a style="text-decoration:none;color:black;" href="readmore.php?id=' .
			$row['ID'] . '"><p align="justify">' .
			//https://thisinterestsme.com/php-get-first-character-string/
			substr($row['Content'], 0, 40) . '... <i style="color: red;" >Read More</i> </p></a><p align="right">'
			. $d . ' ' . $dc . ', ' . $dy . ' </p><hr>';
	}
	//https://stackoverflow.com/questions/37872654/pagination-ceiling-an-array-using-pdo
	//if the id value is greater then 1 there will be a option to go to the previous posts,
	if ($id > 1) {
		echo '<a href="?id=' . $id - 1 . '">Prev </a>';
	}
	//https://stackoverflow.com/questions/37872654/pagination-ceiling-an-array-using-pdo
	//if the id value is less then the total amount of pages found using the ceil function
	// there will be a option to go to the next posts,
	//however, for some reasons these codes are not working. It will works
	//the reason why they are not working is on the database the id's are initially greater than 0,where they are set to increment.
	//if it is done manually they work
	if ($id < $total) {
		echo '<a href="?id=' . $id + 1 . '">Next </a>';
	}
}

require 'footer.php';

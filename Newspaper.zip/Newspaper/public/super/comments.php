<?php
//Comments are displayed here
$tag = 'Manage Comments';
$heading = 'Approve/Delete Comments';
//call navbar
require 'superAdminDashNav.php';
require 'comments_code.php';

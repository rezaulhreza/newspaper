<?php

//this is for posting articles


//title for front end
$tag = 'Add post';
$heading = 'Add a new Article';
//call nav bar
require 'superAdminDashNav.php';
require 'post_code.php';

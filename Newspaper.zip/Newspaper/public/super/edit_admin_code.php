<?php
require '../connect.php';

//pass the id variable to url parameter via get method
$id = $_GET['id'];
//prepare the statement
$sql = $pdo->prepare("SELECT * FROM admin WHERE `ID` = ?");
//execute the value of array id
$sql->execute([$id]);
//return the row from the stmt
$find  = $sql->fetch();


//if submit is pressed run this

if (isset($_POST['submit'])) {




    $username = $_POST['username'];

    //if the password is changed and have differences with the one in the cb 
    //convert the plain text into random strings and numbers

    $password = $_POST['password'];
    if ($password != $find['Password']) {
        $password = password_hash($password, PASSWORD_DEFAULT);
    }


    //prepare the stmt to update the row username and password

    $sql = $pdo->prepare("UPDATE `admin` SET `Username`= ? , `Password` = ? WHERE `ID` = ?");
    //attach the array to named placeholders and execute stmt
    $sql->execute([$username, $password, $id]);
    //return the row which is affected by the last stmt
    $results  = $sql->rowCount();
    //if result is set print this
    if (isset($results)) {
        echo "Record has been successfully updated";
    }
}
?>

<form method="post" action="">

    <label>Username</label> <input type="text" name="username" placeholder="Admin Username" value="<?php echo $find['Username']; ?>" required />
    <label>Password</label> <input type="password" name="password" placeholder="Admin Password" value="<?php echo $find['Password']; ?>" required />

    <input type="submit" name="submit" value="Update" />
</form>
<?php require '../footer.php';

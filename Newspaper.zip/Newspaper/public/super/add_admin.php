<?php

//add admin page
//this option is solely for the admin Type Super
$tag = 'Add Admin';
$heading = 'Add a new admin';
//call the navbar
require 'superAdminDashNav.php';
require 'add_admin_code.php';

<?php


//call database connection file
require '../connect.php';

//select query to retrieve all data from table Posts in descending order
$sql = "SELECT * FROM posts ORDER BY ID DESC";
//fetch all the rows as per the above que
$results  = $pdo->query($sql)->fetchAll();
//if the fetched data is less than 1 then print this
if (count($results) < 1) {
	echo 'No Post added yet!';
} else {
	//if there is any data then print them in below format, which is table based
	echo '	<table>
					<tr>
						<th> Title </th>
						<th> Author </th>
						<th> Actions </th>
					</tr>';
	//go through each and every row of the table post
	foreach ($pdo->query($sql) as $row) {
		echo '<tr>
									<td>' . $row['Title'] . '</td>
									<td>' . $row['Anchor'] . '</td>
									<td> <a style="color: white;background:green;border-radius:1px;text-decoration none;font-size:20px;" href="edit_post.php?id=' . $row['ID'] . '">Edit</a>
									<a style="color: white;background:red;border-radius:1px;text-decoration none;font-size:20px;" href="delete_post.php?id=' . $row['ID'] . '">      Delete</a></td>
								</tr>'; // links to edit post and delete post is stated
	}
}

?>
</table>
<?php require '../footer.php';

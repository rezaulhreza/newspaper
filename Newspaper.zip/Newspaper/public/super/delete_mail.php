<?php
//call session check file
require 'check.php';
//call db connection file
require '../connect.php';
//set the variable id to array through get method to get the id
$id = $_GET['id'];
//prepare the sql statement
$sql = $pdo->prepare("DELETE FROM mails WHERE `ID` = ?");
//execute the sql statement on id
$sql->execute([$id]);
//returns the row affected by the last query and redirect the user 
//to the previous page
$results  = $sql->rowCount();
if (isset($results)) {
    // echo "Mails deleted successfully";
    header('location:mails.php');
}

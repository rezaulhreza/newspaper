<?php
$tag = 'Edit Categories';
//call navbar
require 'superAdminDashNav.php';
require 'edit_cat_code.php';

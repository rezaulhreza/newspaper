<?php

//if submit button is clicked run this
if (isset($_POST['submit'])) {
    //call db file
    require '../connect.php';

    $title = $_POST['title'];
    $anchor = $_SESSION['users'];
    $content = $_POST['content'];
    $category = $_POST['category'];
    //codes for image uploading
    //code taken and modified according to the project purpose from

    // https://justclack.blogspot.com/2017/08/image-upload-in-php-pdo-with-database.html

    if ($_FILES['image']['tmp_name']) {
        $target_dir = "../images/posts/"; //directory where the images will be saved
        $path = $target_dir . basename($_FILES['image']['name']);

        $ext = getimagesize($_FILES['image']['tmp_name']);
        if ($ext == false) {
            die("Invalid Image. You can only upload an Image!");
        } else {
            //variable allowed will go through the given indexes
            //if the extension does not match then it will not allow that image to be uploaded

            $allowed = array('jpg', 'png', 'jpeg');
            if (in_array(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION), $allowed)) {
                if (move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
                    $paths = $path;
                } //error message
                else {
                    die('Unable to upload Image');
                }
                //error message
            } else {
                die('Only jpg, png and jpeg files are allowed.');
            }
        }
    } else {
        //if no image is uploaded then set the path empty
        $paths = '';
    }
    //insert query to insert data into posts table.
    //prepare statement will execute after this
    $stm = $pdo->prepare("INSERT INTO posts (ID,Title,Anchor,Category,Image,Content,Date) VALUES ( :id, :title,:anchor,:category,:image,:content, :date)");
    // inserting a record
    //execute the function by going through the array
    //here id set to null because in db id is set to auto increment

    $stm->execute(array(':id' => NULL, ':title' => $title, ':anchor' => $anchor, ':category' => $category, ':image' => $paths, ':content' => $content, ':date' => date('Y/m/d')));
    echo "Post was added successfully!";
}
?>

<form method="post" action="" enctype="multipart/form-data">

    <label>Title</label> <input type="text" name="title" placeholder="Title" required />

    <label>Category Name</label> <select name="category">

        <?php
        //this query is to get all the data from the category table on the option field
        require '../connect.php';
        $sql = "SELECT * FROM category";
        //go through each row as per the query and get the details from the row 'Name'
        foreach ($pdo->query($sql) as $row) {
            echo "<option>" . $row['Name'] . "</option>";
        }


        ?>


    </select>
    <label>Image (optional)</label> <input type="file" name="image" />
    <label>Content</label> <textarea name="content"></textarea>


    <input type="submit" name="submit" value="Add Post" />
</form>
<?php require '../footer.php';

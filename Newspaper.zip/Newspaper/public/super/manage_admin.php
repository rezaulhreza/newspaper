<?php

//managing admin 
//allow edit and deletion of admin added by the admin type Super
$tag = 'Manage Admin';
$heading = 'Edit/Delete Admin';
//call navbar
require 'superAdminDashNav.php';
require 'manage_admin_code.php';

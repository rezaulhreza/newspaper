<?php
//start the session data
session_start();
//if session is not set redirect the user to main website landing page
if (!isset($_SESSION['users'])) {
    header('location:../index.php');
}

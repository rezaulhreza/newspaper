<?php
//if submit button is pressed run the code below
if (isset($_POST['submit'])) {
    //call db file
    require '../connect.php';

    //set the variable and pass it to the array 
    $username = $_POST['username'];
    //password hashing algorithm which will transform the password into random characters.
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    //set the type to Admin as there is only one Super admin and rest are named as 'Admin'
    $type = 'Admin';

    //Prepare the insert statement to insert data into admin table
    $stm = $pdo->prepare("INSERT INTO admin (ID,Username,Password,Type) VALUES ( :id, :username, :password, :type)");
    // inserting a record  by executing the variables passed in
    $stm->execute(array(':id' => NULL, ':username' => $username, ':password' => $password, ':type' => $type));
    //if execution is successful print this
    echo "New Admin was added successfully";
}
?>

<form method="post" action="">


    <label>Username</label> <input type="text" name="username" placeholder="Admin Name" />
    <label>Password</label> <input type="text" name="password" placeholder="Admin Password" />


    <input type="submit" name="submit" value="Add Admin" />
</form>
<?php
//call footer file
require '../footer.php';

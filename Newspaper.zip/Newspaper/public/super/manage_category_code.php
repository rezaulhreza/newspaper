<?php
//call db connect file
require '../connect.php';
//declare variable
$cat = 'Name';
//pdo prepare statement and query to select everything from category table
$sql = $pdo->prepare("SELECT * FROM category");
//only execute the name variable which is assigned to Name and this
//will execute Name column which will display the name of the categories
$sql->execute([$cat]);
//fetch all elements from the query
$results = $sql->fetchAll();


//if results from the fetch is 0 then print this
if (count($results) < 1) {
    echo 'No category added yet';
} else {
    //if it returns true print this
    echo '	<table>
					<tr>
                        <th> Name </th>
                        <th> Actions</th>
                    </tr>';
    //go through each and every row from the execution of sql statement
    foreach ($results as $row) {
        echo '<tr>
									<td>' . $row['Name'] . '</td>
								
									<td> <a href="edit_cat.php?id=' . $row['ID'] . '">Edit</a><a href="delete_cat.php?id=' . $row['ID'] . '">Delete</a></td>
            </tr>'; ///links to edit and del
    }
}
?>
</table>


<?php


require '../footer.php';

<?php
//add category page
$tag = 'Add categories';
//Add a new category
$heading = 'Add a new category';
//call navbar
require 'superAdminDashNav.php';
require 'add_category_code.php';

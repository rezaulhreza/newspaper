<form method="post" action="">


    <label>Username</label> <input type="text" name="username" placeholder="Username" required />
    <label>Password</label> <input type="password" name="password" placeholder="Password" required />


    <input type="submit" name="submit" value="Login" />
</form>
<?php
require '../super/check.php';

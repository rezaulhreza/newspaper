<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../styles.css" />
    <title>Northampton News-<?php echo $tag ?></title>
</head>

<body>
    <header>
        <section>
            <h1>Northampton News</h1>
        </section>
    </header>

    <img src="images/banners/3.jpg" />
    <main>
        <!-- Delete the <nav> element if the sidebar is not required -->
        <nav>
            <ul>
                <li><a href="../index.php">View Website</a></li>

            </ul>
        </nav>
<?php
require '../super/delete_comment.php';

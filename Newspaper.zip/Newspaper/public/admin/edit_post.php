<?php

$tag = 'Edit Post';
$heading = 'Edit Post Details';
//call navbar
require 'adminDashNav.php';
require '../super/edit_post_code.php';

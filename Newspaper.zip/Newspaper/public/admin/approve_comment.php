<?php
require '../super/approve_comment.php';

<?php
require '../super/delete_cat.php';

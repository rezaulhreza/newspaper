<?php

$tag = 'Edit Categories';
$heading = 'Edit/Delete Category Name';
//call navbar
require 'adminDashNav.php';
require '../super/edit_cat_code.php';

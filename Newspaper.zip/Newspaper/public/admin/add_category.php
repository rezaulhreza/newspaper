<?php
//add category page

$tag = 'Add category';
$heading = 'Add a new category';
//call navbar
require 'adminDashNav.php';

require '../super/add_category_code.php';

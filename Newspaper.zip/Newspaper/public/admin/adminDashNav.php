<?php

//check if there is any session set

// this is the  navigation area for the admin Panel (Secondary)
require 'check.php';
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../styles.css" />
    <title>Northampton News- <?php echo $tag; ?> </title>
</head>

<body>
    <header>
        <section>
            <h1>Northampton News</h1>
        </section>
    </header>

    <img src="images/banners/3.jpg" />
    <main>
        <!-- Delete the <nav> element if the sidebar is not required -->
        <nav>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="post.php">Post Article</a></li>
                <li><a href="mails.php">Contact Mails</a></li>
                <li><a href="add_category.php">Add Category</a></li>
                <li><a href="manage_category.php">Manage Category</a></li>
                <li><a href="comments.php">Manage Comments</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
        <article>
            <h3><?php echo $heading; ?></h3>
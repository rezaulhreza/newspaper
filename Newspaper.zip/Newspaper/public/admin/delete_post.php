<?php
require '../super/delete_post.php';

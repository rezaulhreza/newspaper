<?php
//call the navbar
//manage category file
$tag = 'Manage categories';
$heading = 'Edit/Delete Categories';
require 'adminDashNav.php';
require '../super/manage_category_code.php';

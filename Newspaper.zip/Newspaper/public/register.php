<?php
$tag = 'Registration';
//call navbar
require 'head.php';
//cll db connection file 
require 'connect.php';

//if submit button is clicked this will run
if (isset($_POST['submit'])) {

	$name = $_POST['name']; //for input name 'name'
	$user = $_POST['username']; //for input name 'username'
	$email = $_POST['email']; //for input name 'username'

	$password = 'secret'; // default password
	//password hashing
	//this will change the plain text into a string of letters/numbers/characters
	//what this does is when plain text is converted it adds the default password which is secret in this case,
	//making it impossible to decrypt it
	$hash = password_hash($_POST['password'], PASSWORD_DEFAULT);



	//this will count the Username as number from users table to check
	//if there is any user exists with this name
	$query = "SELECT COUNT(Username) AS num FROM users WHERE Username=:username";
	//prepare the query
	$stm = $pdo->prepare($query);
	//ref: 
	//https://www.youtube.com/watch?v=3RueonbfVPA&list=LL&index=1&t=2281s
	//binding the value which is the parameter of the name from the form
	$stm->bindValue(':username', $user);
	//execute the stmt
	$stm->execute();
	//ref: 
	//https://www.youtube.com/watch?v=3RueonbfVPA&list=LL&index=1&t=2281s
	// bindValue and row num is used from this tutorial to implement existing user check

	//fetch the row from the table
	$row = $stm->fetch();
	//if number of row is more than 0/ if it returns true, display an alert
	if ($row['num'] > 0) {

		echo '<script>alert("User Already Exists! Please try again!");</script>';
	} else {

		//sql query to insert into table
		$sql = "INSERT INTO users (ID,Name,Email,Username,Password) VALUES ( :id, :name,:email,:username,:password)";
		//binding values to array
		$values = [':id' => NULL, ':name' => $name, ':email' => $email, ':username' => $user, ':password' => $hash];
		//prepare the stmt
		$stmt = $pdo->prepare($sql);
		//execute the arrays
		$stmt->execute($values);
		//set the session for the user to the username and redirect to index.php or homepage
		header('location:index.php');
		$_SESSION['users'] = $_POST;
	}
}

require 'regform.php';
require 'footer.php';

<form method="post" action="">


    <label>Name</label> <input type="text" name="name" placeholder="Name" required />
    <label>Email</label> <input type="email" name="email" placeholder="Email" required />
    <label>Username</label> <input type="text" name="username" placeholder="Username" required />
    <label>Password</label> <input type="password" name="password" placeholder="Password" required />

    <input type="submit" name="submit" value="Register" />
</form>
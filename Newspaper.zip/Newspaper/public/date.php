<?php
//strtotime function converts any string to time format
//pass the variable to p to get date from row
$p = strtotime($row['Date']);
// $m variable is for month and add the date same for all if condition matches return true according to variables
// within the if stmt
$m = date('m', $p);
//jan
if ($m == 1)
    $dc = 'JAN';

//feb
elseif ($m == 2)
    $dc = 'FEB';
//march
elseif ($m == 3)
    $dc = 'MAR';
//apr
elseif ($m == 4)
    $dc = 'APR';
//may and so on....
elseif ($m == 5)
    $dc = 'MAY';

elseif ($m == 6)
    $dc = 'JUN';

elseif ($m == 7)
    $dc = 'JUL';

elseif ($m == 8)
    $dc = 'AUG';

elseif ($m == 9)
    $dc = 'SEP';

elseif ($m == 10)
    $dc = 'OCT';

elseif ($m == 11)
    $dc = 'NOV';

else
    $dc = 'DEC';


//d is for day
$d = date("d", $p);
//year
$dy = date("Y", $p);

$dh = date("H", $p);
$di = date("i", $p);
$ds = date("s", $p);

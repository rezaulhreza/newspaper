<?php
$tag = 'Read More';
//call header and nav;
require 'head.php';
//call the search box which is after the navbar
require 'searchbox.php';
//if id is not referred the url parameter then redirect to index.php
//this is for error handling
//if not then get and add the id after the 'id=' ann pass it to the url
if (!isset($_GET['id'])) {
	header('location:index.php');
} else {
	$id = $_GET['id'];
}
//select everything from posts table restricting by id and prepare the statement
$sql = $pdo->prepare("SELECT * FROM posts WHERE `ID` = ?");
//execute the array value/variable $id
$sql->execute([$id]);
//fetch the rwo from the output
$row  = $sql->fetch();

//call date file
require 'date.php';

echo '<h3 align="center"> ' . $row['Title'] . '<br><span style="font-size:13px;">By: <a href="anchor.php?anc=' . $row['Anchor'] . '" style="text-decoration:none;color:black;font-size:13px;">' . $row['Anchor'] . '</a> | ' . $row['Category'] . '</span></h3>';

//the result fetched from the last sql statement execution ,
//if it contains image then run this. logic behind this stated in other file
if ($row['Image']) {
	echo '<p align="center"><img src="admin/' . $row['Image'] . '" " height="240px" width="50%"></p>';
}


//addtoany social media sharing ability.
//it allows the user to share the posts to social media platforms.
//ref
// https://www.addtoany.com/buttons/for/website
echo '<p align="justify"> ' . nl2br($row['Content']) . ' <br>
							<!-- AddToAny BEGIN -->
										<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
										<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
										<a class="a2a_button_facebook"></a>
										<a class="a2a_button_twitter"></a>
										<a class="a2a_button_whatsapp"></a>
										</div>
										<script async src="https://static.addtoany.com/menu/page.js"></script>
									<!-- AddToAny END -->

							</p>';
//print the date month year , from date.php
echo '<p align="right">' . $d . ' ' . $dc . ', ' . $dy . ' </p><hr>';





//this is for comments
//if comment button is submitted then run this
if (isset($_POST['submit'])) {


	//validation
	//if session is not set then display this
	if (!isset($_SESSION['users'])) {
		//using die to terminate the process forcefully
		die('You must <a href="login.php">login</a> to make a comment!');
	} else {
		//if user is logged in
		//pass the $name variable tp session name
		$name = $_SESSION['users']; #
		//pass variable to array using post method
		$comment = $_POST['comment'];
		//set the $variable status to Pending. Which will store it as pending and will not post until it gets approval
		$status = 'Pending';
		//re-assigning id to aid variable
		$aid = $id;
		//insert the comments by running this query using prepare stmt.
		$stm = $pdo->prepare("INSERT INTO comments (SN,ID,Name,Comment,Status,Date) VALUES (:sn, :id, :name, :comment, :status, :date)");
		// inserting a record using array placeholders
		$stm->execute(array(':sn' => NULL, ':id' => $aid, ':name' => $name, ':comment' => $comment, ':status' => $status, ':date' => date('Y/m/d')));
		echo "Comment awaiting Approval!";
	}
}
?>
<h3 align="center"> Comments </h3>
<?php
//if the status is set to Approved by the admin run this
$status = 'Approved';
//prepare the stmt
$sql = $pdo->prepare("SELECT * FROM comments WHERE `ID` = ? AND `Status` = ?");
//execute the prepare stmt by passing array of insert values
$sql->execute([$id, $status]);
//go through each and every row and return the rows where the status is set as 'Approved'
foreach ($sql->fetchAll() as $rows) {
	echo '<b>' . $rows['Name'] . '</b><br>
									<p align="justify"> ' . nl2br($rows['Comment']) . '</p><hr>';
	//n12br will insert a break , which will display each comment separately
}
//call the form for comment
require 'commentbox.php';
require 'footer.php';
